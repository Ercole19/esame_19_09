package com.example.ercole_18_09_exam;
import org.jruby.RubyProcess;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;
import static org.junit.jupiter.api.Assertions.fail;


public class MainPageTest {
    @Test
    public void ercoletest() throws InterruptedException {
        System.setProperty("webdriver.gecko.driver", "src/geckodriver.exe");
        WebDriver driver = new FirefoxDriver();
        driver.get("https://www.bing.com/translator/?from=it&to=en&text=");
        driver.findElement(By.xpath("//*[@id=\"tta_input_ta\"]")).click();

        driver.findElement(By.id("tta_input_ta")).sendKeys("la pizza margherita è senza ananas");
        TimeUnit.SECONDS.sleep(10);
        String result = driver.findElement(By.id("tta_output_ta")).getAttribute("value");

        System.out.println(result);
        String[] tokens = result.split("\\s+");

        System.out.println(tokens.length);
        assert(tokens.length < 10);

    }
}
